using UnityEngine;
using Galactic.CustomPlugins;

namespace TestPlugin
{
    /// <summary>
    /// Test plugin to demonstrate the Galactic custom plugin system
    /// </summary>
    public class MyAwesomePlugin : ICustomPlugin
    {
        public string PluginName => "My Awesome Test Plugin";
        public string Version => "1.0.0";
        public string Author => "Plugin Developer";
        public string Description => "A test plugin with various example mods";

        private bool isSpinning = false;
        private float spinSpeed = 360f;
        private Vector3 savedPosition;
        private bool hasSavedPosition = false;

        public void OnLoad()
        {
            Debug.Log("[MyAwesomePlugin] Plugin loaded successfully!");
        }

        public CustomButtonInfo[] GetMods()
        {
            return new CustomButtonInfo[]
            {
                // Toggle mods
                new CustomButtonInfo { buttonText = "Test Toggle Mod", method = () => TestToggleMod(), isTogglable = true, toolTip = "A simple test toggle that logs every frame" },
                new CustomButtonInfo { buttonText = "Spin Player", enableMethod = () => EnableSpin(), disableMethod = () => DisableSpin(), isTogglable = true, toolTip = "Spins your player around" },

                
                // Button mods (Non toggle)
                new CustomButtonInfo { buttonText = "Log Message", method = () => LogMessage(), isTogglable = false, toolTip = "Logs a test message to console" },
                new CustomButtonInfo { buttonText = "Save Position", method = () => SavePosition(), isTogglable = false, toolTip = "Saves your current position" },
                new CustomButtonInfo { buttonText = "Load Position", method = () => LoadPosition(), isTogglable = false, toolTip = "Teleports you to saved position" },
                new CustomButtonInfo { buttonText = "FPS Logger", method = () => LogFPS(), isTogglable = true, toolTip = "Logs FPS every second" },
            };
        }

        // Toggle mod that runs every frame
        private void TestToggleMod()
        {
            // This runs every frame when enabled
            // Keep it optimized!
            if (Time.frameCount % 300 == 0) // Log every 300 frames (~5 seconds at 60fps)
            {
                Debug.Log("[MyAwesomePlugin] Test toggle is running!");
            }
        }

        // Enable/Disable methods for spin
        private void EnableSpin()
        {
            isSpinning = true;
            Debug.Log("[MyAwesomePlugin] Spin enabled!");
        }

        private void DisableSpin()
        {
            isSpinning = false;
            Debug.Log("[MyAwesomePlugin] Spin disabled!");
        }

        // One-time button actions
        private void LogMessage()
        {
            Debug.Log("[MyAwesomePlugin] Button clicked! This is a test message.");
        }

        private void SavePosition()
        {
            var player = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player");
            if (player != null)
            {
                savedPosition = player.transform.position;
                hasSavedPosition = true;
                Debug.Log($"[MyAwesomePlugin] Position saved: {savedPosition}");
            }
            else
            {
                Debug.LogWarning("[MyAwesomePlugin] Could not find player to save position!");
            }
        }

        private void LoadPosition()
        {
            if (!hasSavedPosition)
            {
                Debug.LogWarning("[MyAwesomePlugin] No saved position! Use 'Save Position' first.");
                return;
            }

            var player = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player");
            if (player != null)
            {
                player.transform.position = savedPosition;
                Debug.Log($"[MyAwesomePlugin] Teleported to: {savedPosition}");
            }
            else
            {
                Debug.LogWarning("[MyAwesomePlugin] Could not find player to teleport!");
            }
        }

        private float lastFPSLog = 0f;
        private void LogFPS()
        {
            if (Time.time - lastFPSLog >= 1f)
            {
                float fps = 1f / Time.deltaTime;
                Debug.Log($"[MyAwesomePlugin] Current FPS: {fps:F1}");
                lastFPSLog = Time.time;
            }
        }
    }
}
